ChangeLog
==============

# Version 0.3.0 (08/19/2019)

- Use Golang modules for dependencies
- `FIX` Ping (#14)
- Update Makefile so make init works correctly (#13)
- Increase HTTP Timeout (#11)

# Version 0.2.0 (01/17/2017)

- `FIX` Initialize correctly client.
- Update dependency to zpeters Speedtest code

# Version 0.1.0 (10/05/2016)

- Prometheus exporter for Speedtest measures
